#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/tests
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d build/tests app/src/main/java/de/meiapps/leseabenteuer/Learning.java app/src/main/java/de/meiapps/leseabenteuer/TraceCourse.java app/src/main/java/de/meiapps/leseabenteuer/FlightCourse.java tests/LearningTest.java tests/PlayTest.java
java -cp build/tests de.meiapps.leseabenteuer.LearningTest
java -cp build/tests de.meiapps.leseabenteuer.PlayTest
