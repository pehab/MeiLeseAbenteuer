package de.meiapps.leseabenteuer;
import java.util.*;
public final class PlayTest {
 static int checks;static void check(boolean condition){checks++;if(!condition)throw new AssertionError("play check "+checks);}
 public static void main(String[] args){
  for(char glyph:TraceCourse.GLYPHS.toCharArray()){
   TraceCourse course=new TraceCourse(glyph);for(int n=0;n<100;n++)course.touch(.99f,.99f,true);check(course.reached==0);check(!course.finished());
   while(!course.finished()){
    int before=course.reached;float[] point=course.points.get(before);course.touch(point[0],point[1],true);check(course.reached>before);
   }check(course.finished());check(!course.touch(0,0,true));
  }
  FlightCourse flight=new FlightCourse("M",new Random(89));flight.paused=true;float before=flight.x;check(flight.step(10)==0&&flight.x==before);flight.paused=false;
  flight.steer(FlightCourse.laneY((flight.targetLane+1)%3));for(int n=0;n<100&&flight.mistakes==0;n++)flight.step(.08f);check(flight.mistakes==1&&flight.collected==0);
  for(int n=0;n<1000&&!flight.finished;n++){flight.steer(FlightCourse.laneY(flight.targetLane));flight.step(.08f);}check(flight.finished&&flight.collected==6);
  before=flight.x;check(flight.step(10)==0&&flight.x==before&&flight.collected==6);
  FlightCourse miss=new FlightCourse("A",new Random(7));miss.steer(.16f);for(int n=0;n<200&&miss.collected==0;n++)miss.step(.08f);check(!miss.finished);check(miss.collected<6);
  System.out.println("PASS: "+checks+" tracing and flight checks");
 }
}
