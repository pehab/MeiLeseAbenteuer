package de.meiapps.leseabenteuer;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.*;
import java.util.*;

/** Device-level checks use real taps and the native accessibility tree, including scrollable layouts. */
public final class SmokeInstrumentation extends Instrumentation {
    private Bundle args;private MainActivity activity;private int checks;
    @Override public void onCreate(Bundle args){this.args=args;start();}
    private void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
    private Object field(String name)throws Exception{java.lang.reflect.Field f=MainActivity.class.getDeclaredField(name);f.setAccessible(true);return f.get(activity);}
    private void call(String name)throws Exception{java.lang.reflect.Method m=MainActivity.class.getDeclaredMethod(name);m.setAccessible(true);runOnMainSync(()->{try{m.invoke(activity);}catch(Exception e){throw new RuntimeException(e);}});waitForIdleSync();}
    private void tap(String text)throws Exception{tap(text,false,false);}
    private void tap(String text,boolean picture)throws Exception{tap(text,picture,true);}
    private void tap(String text,boolean picture,boolean choice)throws Exception{
        for(int attempt=0;attempt<35;attempt++){
            AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();List<AccessibilityNodeInfo> nodes=new ArrayList<>();if(root!=null)nodes.add(root);
            for(int i=0;i<nodes.size();i++){AccessibilityNodeInfo n=nodes.get(i);for(int j=0;j<n.getChildCount();j++){AccessibilityNodeInfo c=n.getChild(j);if(c!=null)nodes.add(c);}
                if(!text.contentEquals(n.getText()==null?"":n.getText())&&!text.contentEquals(n.getContentDescription()==null?"":n.getContentDescription()))continue;
                if(picture&&!"android.widget.LinearLayout".contentEquals(n.getClassName()))continue;
                if(choice&&!picture&&!"android.widget.Button".contentEquals(n.getClassName()))continue;
                AccessibilityNodeInfo target=n;while(target!=null&&!target.isClickable())target=target.getParent();
                if(target!=null&&target.isEnabled()&&target.isVisibleToUser()&&target.performAction(AccessibilityNodeInfo.ACTION_CLICK)){waitForIdleSync();Thread.sleep(100);return;}
            }
            boolean scrolled=false;for(AccessibilityNodeInfo n:nodes)if(n.isScrollable()&&n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){scrolled=true;break;}
            Thread.sleep(scrolled?200:100);
        }throw new AssertionError("Action not reachable: "+text);
    }
    private String choice(Learning.Question q,String option){return q.mode==Learning.Mode.INITIAL?Learning.sound(option).example:q.mode==Learning.Mode.READ?Learning.word(option).text:q.mode==Learning.Mode.ALPHABET?option.toLowerCase(Locale.GERMAN):option;}
    private void screenshot(String name)throws Exception{android.graphics.Bitmap bitmap=getUiAutomation().takeScreenshot();if(bitmap!=null){ByteArrayOutputStream bytes=new ByteArrayOutputStream();bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,bytes);bitmap.recycle();Bundle snapshot=new Bundle();snapshot.putString("image_"+name,android.util.Base64.encodeToString(bytes.toByteArray(),android.util.Base64.NO_WRAP));sendStatus(0,snapshot);}}
    private void pointer(int action,float x,float y,long down)throws Exception{android.view.MotionEvent e=android.view.MotionEvent.obtain(down,android.os.SystemClock.uptimeMillis(),action,x,y,0);sendPointerSync(e);e.recycle();}
    private void drawGuide(TraceGame view)throws Exception{
        int[] location=new int[2];runOnMainSync(()->view.getLocationOnScreen(location));
        for(int stroke=0;stroke<view.course.strokeStarts.size();stroke++){
            int begin=view.course.strokeStarts.get(stroke),end=stroke+1<view.course.strokeStarts.size()?view.course.strokeStarts.get(stroke+1):view.course.points.size();long down=android.os.SystemClock.uptimeMillis();
            for(int n=begin;n<end;n++){float[] p=view.course.points.get(n);pointer(n==begin?android.view.MotionEvent.ACTION_DOWN:android.view.MotionEvent.ACTION_MOVE,location[0]+view.screenX(p[0]),location[1]+view.screenY(p[1]),down);Thread.sleep(6);}
            float[] p=view.course.points.get(end-1);pointer(android.view.MotionEvent.ACTION_UP,location[0]+view.screenX(p[0]),location[1]+view.screenY(p[1]),down);waitForIdleSync();
        }
    }
    private void steer(FlightGame view,int lane)throws Exception{int[] location=new int[2];runOnMainSync(()->view.getLocationOnScreen(location));long down=android.os.SystemClock.uptimeMillis();float x=location[0]+view.getWidth()*.22f,y=location[1]+view.getHeight()*FlightCourse.laneY(lane);pointer(android.view.MotionEvent.ACTION_DOWN,x,y,down);pointer(android.view.MotionEvent.ACTION_MOVE,x,y,down);pointer(android.view.MotionEvent.ACTION_UP,x,y,down);}
    private void checkAudioAssets()throws Exception{
        for(Learning.Sound sound:Learning.SOUNDS){
            java.util.concurrent.CountDownLatch complete=new java.util.concurrent.CountDownLatch(1);
            java.util.concurrent.atomic.AtomicBoolean failed=new java.util.concurrent.atomic.AtomicBoolean();
            android.media.MediaPlayer[] playback=new android.media.MediaPlayer[1];
            runOnMainSync(()->{
                android.media.MediaPlayer player=new android.media.MediaPlayer();playback[0]=player;
                try(android.content.res.AssetFileDescriptor asset=getTargetContext().getAssets().openFd("sounds/"+sound.letter.toLowerCase(Locale.ROOT)+".ogg")){
                    player.setDataSource(asset.getFileDescriptor(),asset.getStartOffset(),asset.getLength());
                    player.setOnCompletionListener(p->complete.countDown());
                    player.setOnErrorListener((p,what,extra)->{failed.set(true);complete.countDown();return true;});
                    player.prepare();check(player.getDuration()>100,"learning sound has audible duration: "+sound.letter);player.start();
                }catch(Exception e){failed.set(true);complete.countDown();}
            });
            boolean finished=complete.await(5,java.util.concurrent.TimeUnit.SECONDS);
            runOnMainSync(()->playback[0].release());
            check(finished&&!failed.get(),"bundled sound decodes and completes offline: "+sound.letter);
        }
    }
    @Override public void onStart(){Bundle result=new Bundle();try{
        Context context=getTargetContext();activity=(MainActivity)startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));waitForIdleSync();Thread.sleep(1000);
        Progress progress=(Progress)field("progress");
        if("seed".equals(args.getString("phase"))){runOnMainSync(()->{progress.name("Update-Kind");progress.record("LISTEN:M",false);progress.finish(5);});check(context.getSharedPreferences("learning-v1",0).edit().commit(),"upgrade fixture flushed to disk before stopping instrumentation");result.putString("summary","PASS: seeded existing child profile for upgrade");finish(Activity.RESULT_OK,result);return;}
        if("upgrade".equals(args.getString("phase"))){check(progress.name().equals("Update-Kind"),"child name survives APK update (actual: "+progress.name()+", rounds: "+progress.rounds()+")");check(progress.stars()==1&&progress.completed()==1,"progress survives APK update");check(progress.get("LISTEN:M").independent==1,"individual skill history survives update");result.putString("summary","PASS: "+checks+" upgrade preservation assertions");finish(Activity.RESULT_OK,result);return;}
        if("reopen".equals(args.getString("phase"))){check(progress.profile()==0,"selected profile persists");check(progress.stars()==9&&progress.rounds()==9,"completed rounds and rewards persist after process restart");check(progress.completed()==4,"independent rounds persist");check(Learning.known(progress.completed())==4,"letter progression persists");result.putString("summary","PASS: "+checks+" restart assertions");finish(Activity.RESULT_OK,result);return;}
        checkAudioAssets();
        check(progress.stars()==0,"fresh installation has no rewards");screenshot("home.png");
        String[] names={"Laute lauschen","Bildersuche","Laute verbinden","Wörter entdecken","Buchstabenpaare","Mengen zählen","Zahlen finden"};
        for(int mode=0;mode<names.length;mode++){
            tap(names[mode]);Learning.Question q=null;
            for(int attempt=0;attempt<100;attempt++){waitForIdleSync();q=(Learning.Question)field("question");if(q!=null&&q.mode.ordinal()==mode)break;Thread.sleep(50);}
            check(q!=null&&q.mode.ordinal()==mode,"requested game opens after the accessibility action");
            Learning.Round round=(Learning.Round)field("round");
            tap("Aufgabe noch einmal hören");check(!round.assisted,"repeat is independent and does not expose the solution");
            if(mode==2||mode==3){tap("Hilf mir: gemeinsam lösen");check(round.assisted&&(Boolean)field("hint"),"help reveals the solution and marks the attempt assisted");}
            String wrong=null;for(String option:q.options)if(!option.equals(q.target)){wrong=option;break;}tap(choice(q,wrong),q.mode==Learning.Mode.INITIAL||q.mode==Learning.Mode.READ);check(round.assisted&&round.answered==0,"wrong answer helps instead of advancing");
            for(int n=0;n<6;n++){
                q=(Learning.Question)field("question");String label=choice(q,q.target);tap(label,q.mode==Learning.Mode.INITIAL||q.mode==Learning.Mode.READ);check(round.answered==n+1,"real tap advances exactly once");
                if(n==0)check(round.independent==0,"retry is not counted as independent");
                if(n==0)screenshot("game-"+mode+".png");
                tap(n==5?"Mein Abenteuerstern":"Weiter →");
            }
            check(progress.stars()==mode+1,"one reward per finished round");tap("Zur Lichtung");
        }
        tap("Nachmalen");waitForIdleSync();
        for(int n=0;n<6;n++){
            TraceGame view=(TraceGame)field("traceGame");check(view!=null,"finger tracing game opens");Learning.Round tracing=(Learning.Round)field("round");
            int[] location=new int[2];runOnMainSync(()->view.getLocationOnScreen(location));long down=android.os.SystemClock.uptimeMillis();pointer(android.view.MotionEvent.ACTION_DOWN,location[0]+view.getWidth()*.99f,location[1]+view.getHeight()*.99f,down);pointer(android.view.MotionEvent.ACTION_UP,location[0]+view.getWidth()*.99f,location[1]+view.getHeight()*.99f,down);check(view.course.reached==0,"off-guide tap does not complete writing");
            drawGuide(view);check(tracing.answered==n+1,"actual finger path completes exactly one writing task");if(n==0)screenshot("tracing.png");tap(n==5?"Mein Abenteuerstern":"Weiter →");
        }check(progress.stars()==8,"tracing round awards one star");tap("Zur Lichtung");
        tap("Buchstabenflug");waitForIdleSync();FlightGame flight=(FlightGame)field("flightGame");check(flight!=null,"touch-steered flight opens");steer(flight,(flight.course.targetLane+1)%3);
        for(int attempt=0;attempt<200&&flight.course.mistakes==0;attempt++){Thread.sleep(50);waitForIdleSync();}
        check(flight.course.mistakes==1&&flight.course.collected==0&&progress.stars()==8,"wrong letter gives no collection or reward");screenshot("flight.png");
        for(int attempt=0;attempt<1000&&progress.stars()<9;attempt++){steer(flight,flight.course.targetLane);Thread.sleep(50);waitForIdleSync();}
        check(flight.course.finished&&flight.course.collected==6,"six correct letters collected through real steering");check(progress.stars()==9,"flight awards exactly one star");tap("Zur Lichtung");
        check(progress.completed()==4,"number and alphabet rounds do not advance phonics progression");
        check(progress.numberCompleted()==2,"number rounds have separate progress");
        tap("Meine Waldtiere");screenshot("album.png");tap("Milo");tap("Zurück zur Abenteuerkarte");
        tap("ABC entdecken");screenshot("alphabet.png");tap("Z, Zebra");tap("Zurück zur Abenteuerkarte");
        runOnMainSync(()->progress.profile(1));check(progress.stars()==0&&progress.completed()==0,"other child has independent progress");
        runOnMainSync(()->progress.profile(0));check(progress.stars()==9,"original child progress preserved");java.lang.reflect.Method home=MainActivity.class.getDeclaredMethod("home",boolean.class);home.setAccessible(true);runOnMainSync(()->{try{home.invoke(activity,false);}catch(Exception e){throw new RuntimeException(e);}});waitForIdleSync();
        screenshot("home-progress.png");check(context.getSharedPreferences("learning-v1",0).edit().commit(),"profile data flushed before restart check");result.putString("summary","PASS: "+checks+" Android interaction assertions");finish(Activity.RESULT_OK,result);
    }catch(Throwable error){try{screenshot("failure.png");}catch(Exception ignored){}result.putString("error",android.util.Log.getStackTraceString(error));finish(Activity.RESULT_CANCELED,result);}}
}
