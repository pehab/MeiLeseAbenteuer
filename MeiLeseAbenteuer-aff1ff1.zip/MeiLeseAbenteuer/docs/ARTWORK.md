# Bildgrafiken für MeiLeseAbenteuer 0.3.0

Die Bilder wurden mit dem eingebauten Imagegen-Werkzeug erstellt. MeiTowerdefence diente als Referenz für die grafische Qualität; dessen Bilddateien wurden nicht übernommen. Die neuen Bilder sind heller und auf Vorschulkinder zugeschnitten.

## Projektdateien

- `app/src/main/res/drawable-nodpi/woodland_animals.webp`: sechs Waldtiere als transparenter Bildatlas.
- `app/src/main/res/drawable-nodpi/woodland_background.webp`: Waldlandschaft für die Abenteuerkarte.
- `app/src/main/res/drawable-nodpi/learning_pictures.webp`: Lernbilder als transparentes 4×4-Raster.
- `app/src/main/res/drawable-nodpi/learning_details.webp`: Nase und einzelne rote Frucht.

Die Originalbilder wurden zur Einbettung in WebP umgewandelt. Alphakanäle bleiben erhalten. `ArtAssets.java` lädt die Bilder einmalig und stellt Ausschnitte mit beibehaltenem Seitenverhältnis dar. Karten und Belohnungen verwenden dieselben Figuren. Die Bewegungen werden nativ animiert; die Bilddateien selbst sind keine Frame-Animationen.

## Verwendete Prompts

### Tiere

Use case: stylized-concept. Asset type: production-ready transparent character sprite atlas for a children's Android learning adventure. Create ONE atlas, exact regular grid of 3 columns and 2 rows, six separate full-body woodland animals, generous transparent margins inside each equal cell, no overlap, no objects crossing cells. Left-to-right top row: Milo a clearly recognizable young RED FOX with pointed triangular ears, long narrow white muzzle, black paws and large bushy tail with a white tip; Luna a clearly recognizable cream-white RABBIT with two very long upright ears with pink interiors, rabbit hind feet, little visible front teeth, lavender scarf; Bruno a friendly BROWN BEAR cub with round ears, broad bear muzzle, stocky body and short tail. Left-to-right bottom row: Pia a small BLUE SONG BIRD with yellow beak, feathered wings, visible tail feathers and two little feet, absolutely NO mammal ears; Rosa a RED SQUIRREL with prominent huge curved fluffy tail and tufted ears holding one acorn; Fritzi a GREEN FROG with wide frog mouth, raised round eyes, webbed toes and crouching frog legs, absolutely NO mammal nose, fur or ears. Style: premium richly textured 3D storybook game characters, soft realistic fur or feathers where appropriate, warm cinematic light, bright and kind preschool-friendly expressions, coherent art direction, high-quality mobile game collectible characters. Clear species anatomy is essential. All six facing camera in slight three-quarter view, full bodies entirely visible, comparable perceived size, clean readable silhouettes at small icon sizes. No captions, no lettering, no borders, no card background, no environmental backdrop, no checkerboard. Actual transparent background.

### Hintergrund

Use case: stylized-concept. Asset type: landscape background image for a children's mobile learning adventure. A beautiful premium 3D storybook woodland clearing, inviting winding sandy footpath through lush grass and wildflowers, a small sparkling pond on the right, flowering shrubs, softly sculpted trees, a charming distant treehouse. High quality rich natural textures and soft volumetric morning sunlight, bright green, turquoise, warm honey palette, harmonious with friendly detailed 3D woodland animals. Wide landscape composition, foreground at lower edge, quiet clear middle area for game route markers and characters, excellent visual depth. This is background artwork only: NO animals, NO people, NO letters, NO text, NO signs, NO buttons, NO UI, no borders, no logos. Not flat geometric vector art, no photoreal photographic harshness.

### Lernbilder

Use case: stylized-concept. Asset type: ONE square production sprite atlas for a preschool reading game. Precisely 4 equal columns and 4 equal rows, each object centered entirely within its own equal cell, generous empty transparent padding of at least 10 percent of every cell, absolutely no touching or overlap between cells. Consistent premium richly textured 3D storybook mobile game art, soft realistic materials, warm light, cheerful and immediately recognizable from a small thumbnail. In strict reading order: ROW 1: a cute grey MOUSE with round pink ears and long thin tail; a friendly brown MONKEY with curled tail; a modern cooking OVEN with visible oven door and knobs; a table LAMP with lampshade. ROW 2: a small brown HEDGEHOG with unmistakable spines; a friendly child's face portrait featuring a clearly visible central human NOSE; a round analogue CLOCK with two clear hands and no numbers; a colourful FISH with fins and tail. ROW 3: an adult MOTHER portrait, kind brown-haired young woman; a GRANDMOTHER portrait with grey hair bun and glasses, clearly older; a full-body LLAMA with long neck and long ears; a full-body RED FOX with pointed ears and bushy white-tipped tail. ROW 4: a clear glass of yellow LEMONADE with a lemon slice and straw; a friendly toy flying saucer UFO; a small woven BASKET of red BERRIES; an open STORYBOOK with blank pages. No captions, no letters, no words, no cell backgrounds, no checkerboard, no border or grid lines. True transparent background. Strict equal cell grid placement is essential because the app will address each cell by row and column.

### Details

Use case: stylized-concept. Asset type: ONE transparent two-cell game sprite atlas, a wide image with exactly TWO equal square cells side by side, ample transparent padding inside each cell and no overlap. LEFT cell: a clearly recognizable human NOSE in front-facing close-up, warm skin, show the nose bridge, tip and both nostrils, just a small oval of surrounding cheek skin, NOT a whole face, no eyes, no mouth, no scary anatomical cutaway; soft friendly 3D preschool storybook rendering. RIGHT cell: ONE single plump round RED BERRY with a tiny green leaf on top, shiny textured fruit skin and soft highlight, clearly a single countable object, no cluster, no basket, no hands. Consistent premium mobile children's game 3D imagery, gentle warm lighting, legible at small size. No labels, no text, no logos, no cell backgrounds, no border, actual transparent background.

