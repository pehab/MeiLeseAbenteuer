# MeiLeseAbenteuer 0.3.0 · Fliegen und Nachmalen

- Neues Flugspiel mit Fingersteuerung: auf dem Papierflieger den gesuchten Buchstaben sammeln. Bewegte Wolken, schwingende Flügel und sichtbare Sammelpunkte. Keine verlorenen Leben und kein Zeitdruck.
- Neues Nachmalspiel für A–Z und 0–9: einer geordneten Spur folgen, am goldenen Punkt ansetzen und bei mehreren Strichen neu ansetzen. Hilfe führt den Weg vor.
- Neuer hochwertiger Bildsatz für alle sechs Waldtiere, Abenteuerkarte und Lernbilder. Luna ist ein Hase mit langen Ohren; Fuchs, Bär, Vogel, Eichhörnchen und Frosch haben eindeutig erkennbare Formen. Sanfte native Bewegungen für Figuren und Wolken.
- Beide Spiele geben Abenteuersterne; Lese- und Zahlenfortschritt bleiben getrennt. Profile und bisherige Fortschritte bleiben beim Update erhalten.

- Konsonanten M, L, N und F neu aufbereitet: natürliche Lautanfänge statt wiederholter Mikroausschnitte; keine künstliche Verlängerung, angepasste Lautstärke und sanfte Ränder. Keine zusätzlichen Vokale oder Buchstabennamen in den Lautspielen.
- Im Elternbereich lassen sich alle acht aufgenommenen Lernlaute einzeln anhören, unabhängig von der installierten deutschen Stimme.

Die technische Prüfung kontrolliert die Übereinstimmung mit dem natürlichen Originalabschnitt und die Wiedergabe auf Android. Verständlichkeit und angenehmer Klang müssen im gemeinsamen Hörtest beurteilt werden; die Aufnahmen bleiben kurze Ausschnitte phonetischer Referenzaufnahmen.
