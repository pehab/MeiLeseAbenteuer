#!/usr/bin/env python3
"""Regression checks: shipped consonants match one natural take, not a repeated loop."""
import hashlib
import importlib.util
import json
import math
import sys
sys.dont_write_bytecode = True
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('phonemes', ROOT / 'scripts/prepare-phonemes.py')
phonemes = importlib.util.module_from_spec(spec)
spec.loader.exec_module(phonemes)
records = json.loads((ROOT / 'docs/audio-adaptations.json').read_text())
for letter in 'mlnf':
    source, expected, gain = phonemes.prepare(letter)
    path = ROOT / 'app/src/main/assets/sounds' / (letter + '.ogg')
    record = records[letter]
    assert hashlib.sha256(source.read_bytes()).hexdigest() == record['source_sha256'], letter + ': changed source'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], letter + ': undocumented asset'
    assert record['source_section_seconds'] == list(phonemes.CUTS[letter][:2])
    actual = phonemes.decode(path)
    assert abs(len(actual)-len(expected)) <= 1024, letter + ': unexpected duration (loop or stretch)'
    length = min(len(actual), len(expected))
    dot = sum(actual[i]*expected[i] for i in range(length))
    denominator = math.sqrt(sum(s*s for s in actual) * sum(s*s for s in expected))
    similarity = dot / denominator
    assert similarity > .94, (letter, 'waveform differs from natural take', similarity)
    assert max(abs(s) for s in actual) < .90, letter + ': clipping'
    assert math.sqrt(sum(s*s for s in actual[:660])/660) < .002, letter + ': missing quiet onset'
    assert math.sqrt(sum(s*s for s in actual[-2000:])/2000) < .002, letter + ': missing quiet ending'
    print('PASS:', letter.upper(), 'single natural take, %.3fs, waveform correlation %.4f' % (len(actual)/phonemes.RATE, similarity))
print('PASS: consonant assets retain natural timing without repeated microsegments')
