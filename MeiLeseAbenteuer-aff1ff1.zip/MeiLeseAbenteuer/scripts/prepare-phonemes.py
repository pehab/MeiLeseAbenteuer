#!/usr/bin/env python3
"""Keep natural consonant onsets; never loop, stretch or synthesize a learning sound.
Run from any directory. Original licensed recordings are deliberately retained.
Requires ffmpeg; everything else uses the Python standard library.
"""
from array import array
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RATE = 44100
# Stop before the following vowel begins in the original recording.
# Preserve the onset and its natural changes instead of repeating a steady fragment.
CUTS = {'m': (.205, .380, .10), 'l': (.210, .480, .10),
        'n': (.240, .500, .10), 'f': (.205, .530, .055)}

def decode(path):
    samples = array('f')
    samples.frombytes(subprocess.check_output([
        'ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le',
        '-ac', '1', '-ar', str(RATE), '-']))
    if sys.byteorder != 'little':
        samples.byteswap()
    return samples

def prepare(letter):
    start, end, target_rms = CUTS[letter]
    source = ROOT / 'audio-originals' / (letter + '.ogg')
    samples = decode(source)[round(start * RATE):round(end * RATE)]
    mean = sum(samples) / len(samples)
    samples = [s - mean for s in samples]
    rms = math.sqrt(sum(s*s for s in samples) / len(samples))
    gain = min(target_rms / max(rms, 1e-8), .80 / max(abs(s) for s in samples))
    fade = round(.008 * RATE)
    for n in range(len(samples)):
        samples[n] *= gain * min(1., n / fade, (len(samples)-1-n) / fade)
    # Brief silence avoids abrupt onset/cutoff and gives short sounds room to be heard.
    result = array('f', [0.] * round(.025 * RATE) + samples + [0.] * round(.060 * RATE))
    return source, result, gain

def main():
    changes = {}
    for letter in CUTS:
        source, samples, gain = prepare(letter)
        if sys.byteorder != 'little':
            samples.byteswap()
        destination = ROOT / 'app/src/main/assets/sounds' / (letter + '.ogg')
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'f32le',
                        '-ar', str(RATE), '-ac', '1', '-i', '-',
                        '-map_metadata', '-1', '-c:a', 'libvorbis', '-q:a', '6', str(destination)],
                       input=samples.tobytes(), check=True)
        changes[letter] = {
            'source_section_seconds': list(CUTS[letter][:2]),
            'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'adaptation': 'single natural consonant onset; no repetition, looping, time stretching or pitch changes; DC removal, gain adjustment, 8ms edge fades, 25/60ms silence padding',
            'gain_db': round(20 * math.log10(gain), 2),
            'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}
    (ROOT / 'docs/audio-adaptations.json').write_text(json.dumps(changes, indent=2) + '\n')
    records = json.loads((ROOT / 'docs/audio-sources.json').read_text())
    lines = ['LAUTAUFNAHMEN · MIT NAMENSNENNUNG', '',
             'Lizenz: CC BY-SA 3.0 Unported.',
             'https://creativecommons.org/licenses/by-sa/3.0/',
             'Die Lautdateien und ihre Bearbeitungen stehen unter dieser Lizenz. Programmcode und Bilder sind unabhängig davon.', '']
    for record in records:
        letter = record['letter']
        author = 'Peter Isotalo' if letter in CUTS else 'Denelson83'
        lines += [letter.upper() + ': ' + record['file'] + ' — ' + author,
                  'https://commons.wikimedia.org/wiki/File:' + record['file'].replace(' ', '_'),
                  ('Bearbeitung: Ein natürlicher Konsonantenanfang ohne Folgevokal; keine Wiederholung oder künstliche Verlängerung. Lautstärke angepasst, Ränder sanft ein-/ausgeblendet, kurze Stille ergänzt.'
                   if letter in CUTS else 'Unveränderte Originalaufnahme.'), '']
    (ROOT / 'app/src/main/assets/AUDIO-CREDITS.txt').write_text('\n'.join(lines))
    print('Prepared four natural consonants without loops; four original vowels unchanged.')

if __name__ == '__main__':
    main()
