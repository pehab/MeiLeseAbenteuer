package de.meiapps.leseabenteuer;

import android.content.Context;
import android.graphics.*;

/** Optimized, bundled image atlases. No network fetches, no new bitmaps allocated during drawing. */
final class ArtAssets {
    private static ArtAssets instance;
    private final Bitmap animals,landscape,pictures,details;private final Paint paint=new Paint(3);
    private final Rect[] animalCells={new Rect(0,0,620,540),new Rect(620,0,1010,540),new Rect(1010,0,1536,540),new Rect(0,540,560,1024),new Rect(560,540,1030,1024),new Rect(1030,540,1536,1024)};
    private final Rect[] pictureCells=new Rect[16];private final Rect[] detailCells=new Rect[2];private final RectF destination=new RectF();
    private ArtAssets(Context context){android.content.res.Resources r=context.getResources();animals=BitmapFactory.decodeResource(r,R.drawable.woodland_animals);landscape=BitmapFactory.decodeResource(r,R.drawable.woodland_background);pictures=BitmapFactory.decodeResource(r,R.drawable.learning_pictures);details=BitmapFactory.decodeResource(r,R.drawable.learning_details);
        if(animals==null||landscape==null||pictures==null||details==null)throw new IllegalStateException("Missing game artwork");
        for(int n=0;n<16;n++)pictureCells[n]=new Rect((n%4)*pictures.getWidth()/4,(n/4)*pictures.getHeight()/4,(n%4+1)*pictures.getWidth()/4,(n/4+1)*pictures.getHeight()/4);
        for(int n=0;n<2;n++)detailCells[n]=new Rect(n*details.getWidth()/2,0,(n+1)*details.getWidth()/2,details.getHeight());
    }
    static synchronized ArtAssets get(Context context){if(instance==null)instance=new ArtAssets(context.getApplicationContext());return instance;}
    private void draw(Canvas c,Bitmap bitmap,Rect source,float l,float t,float r,float b,float pixelAspect){
        float aspect=source.width()/(float)source.height()/Math.max(.01f,pixelAspect),w=r-l,h=b-t;if(w/h>aspect)w=h*aspect;else h=w/aspect;
        destination.set((l+r-w)/2,(t+b-h)/2,(l+r+w)/2,(t+b+h)/2);c.drawBitmap(bitmap,source,destination,paint);
    }
    void animal(Canvas c,int index,float l,float t,float r,float b,float pixelAspect){draw(c,animals,animalCells[Math.floorMod(index,6)],l,t,r,b,pixelAspect);}
    void background(Canvas c,float w,float h){destination.set(0,0,w,h);c.drawBitmap(landscape,null,destination,paint);}
    void berry(Canvas c,float l,float t,float r,float b,float pixelAspect){draw(c,details,detailCells[1],l,t,r,b,pixelAspect);}
    void picture(Canvas c,String kind,float w,float h){
        if(kind.equals("fox")){animal(c,0,0,0,w,h,1);return;}
        if(kind.equals("nose")){draw(c,details,detailCells[0],0,0,w,h,1);return;}
        int index;
        switch(kind){case "mouse":index=0;break;case "monkey":index=1;break;case "oven":index=2;break;case "lamp":index=3;break;case "hedgehog":index=4;break;case "clock":index=6;break;case "fish":index=7;break;case "mother":index=8;break;case "grandmother":index=9;break;case "llama":index=10;break;case "lemonade":index=12;break;case "ufo":index=13;break;case "basket":index=14;break;case "book":index=15;break;default:throw new IllegalArgumentException("Unknown picture "+kind);}
        draw(c,pictures,pictureCells[index],0,0,w,h,1);
    }
}
