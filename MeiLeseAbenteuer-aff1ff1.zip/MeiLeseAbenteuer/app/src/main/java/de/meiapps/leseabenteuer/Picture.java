package de.meiapps.leseabenteuer;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/** All learning pictures use bundled image assets with clear, recognisable subjects. */
final class Picture extends View {
    private final String kind;private final ArtAssets art;
    Picture(Context context){this(context,"fox");}
    Picture(Context context,String kind){super(context);this.kind=kind;art=ArtAssets.get(context);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);art.picture(c,kind,getWidth(),getHeight());}
}
