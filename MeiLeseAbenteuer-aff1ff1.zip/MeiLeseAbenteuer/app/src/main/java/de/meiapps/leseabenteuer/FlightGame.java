package de.meiapps.leseabenteuer;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.*;
import java.util.Random;
import java.util.function.IntConsumer;

/** A continuous, touch-steered flight, drawn natively with parallax clouds and animated wings. */
final class FlightGame extends View {
    final FlightCourse course;private final Paint paint=new Paint(3);private final Path wing=new Path();private final IntConsumer event;private final ArtAssets art;private long last;private float time;private boolean active;boolean hint;
    FlightGame(Context context){this(context,"M",new Random(),n->{});}
    FlightGame(Context context,String target,Random random,IntConsumer event){super(context);course=new FlightCourse(target,random);this.event=event;art=ArtAssets.get(context);setContentDescription("Buchstabenflug. Ziehe den Finger nach oben oder unten und sammle "+target+".");setFocusable(true);}
    private void oval(Canvas c,float x,float y,float rx,float ry,int color){paint.setColor(color);paint.setStyle(Paint.Style.FILL);c.drawOval(x-rx,y-ry,x+rx,y+ry,paint);}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();active=true;last=0;invalidate();}
    @Override protected void onDetachedFromWindow(){active=false;last=0;super.onDetachedFromWindow();}
    @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);last=0;if(visibility==VISIBLE)invalidate();}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);long now=SystemClock.uptimeMillis();if(last!=0&&!course.paused){float dt=Math.min(.08f,(now-last)/1000f);time+=dt;int result=course.step(dt);if(result!=0)post(()->{if(active&&isAttachedToWindow())event.accept(result);});}last=now;
        Canvas c=canvas;c.save();c.scale(getWidth()/100f,getHeight()/100f);c.drawColor(0xffbce8fa);oval(c,83,14,9,7,0xffffdc75);
        for(int n=0;n<5;n++){float x=(n*28-time*(2+n%2))%140;if(x<-20)x+=140;float y=12+n*16;oval(c,x,y,17,4,0xccffffff);oval(c,x-4,y-3,8,5,0xccffffff);}
        oval(c,10,113,80,26,0xff8acfa2);oval(c,97,110,68,23,0xff62b9a1);
        for(int lane=0;lane<3;lane++){float x=course.x*100,y=FlightCourse.laneY(lane)*100;oval(c,x,y,7,6,0xff4c8eaa);oval(c,x,y-1,7,6,hint&&lane==course.targetLane?0xffa6e8a5:0xffffe49b);paint.setColor(0xff38445f);paint.setTypeface(Typeface.create("sans-serif-rounded",Typeface.BOLD));paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(8);c.drawText(course.letters[lane],x,y+1.6f,paint);}
        c.save();c.translate(22,course.y*100);float flap=(float)Math.sin(time*6)*3;
        wing.rewind();wing.moveTo(-16,4);wing.lineTo(17,0);wing.lineTo(-5,11+flap);wing.close();paint.setColor(0xfff6f4e4);c.drawPath(wing,paint);art.animal(c,0,-10,-22,10,5,getWidth()/(float)Math.max(1,getHeight()));c.restore();
        for(int n=0;n<6;n++)oval(c,30+n*8,94,2.2f,1.8f,n<course.collected?0xffffc74e:0x88ffffff);c.restore();
        if(active&&getWindowVisibility()==VISIBLE&&!course.finished&&!course.paused)postInvalidateOnAnimation();
    }
    @Override public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE){getParent().requestDisallowInterceptTouchEvent(true);course.steer(e.getY()/Math.max(1,getHeight()));invalidate();return true;}if(action==MotionEvent.ACTION_UP){performClick();return true;}return true;}
    @Override public boolean performClick(){super.performClick();return true;}
}
