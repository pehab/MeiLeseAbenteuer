package de.meiapps.leseabenteuer;

import java.util.*;

/** Ordered, centre-line writing guides. A stationary tap or off-guide scribble cannot complete them. */
final class TraceCourse {
    static final String GLYPHS="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final String[] ROUTES={
        "15,85 50,15 85,85;30,58 70,58", "25,85 25,15 60,15 78,25 78,38 60,49 25,49;60,49 82,59 82,73 65,85 25,85",
        "82,25 68,15 40,15 22,30 17,50 22,72 40,85 68,85 82,75", "25,85 25,15 52,15 77,30 83,50 77,72 52,85 25,85",
        "80,15 25,15 25,85 80,85;25,49 68,49", "25,85 25,15 80,15;25,49 68,49", "82,26 68,15 40,15 22,30 17,50 22,72 40,85 68,85 82,72 82,52 56,52",
        "25,15 25,85;75,15 75,85;25,50 75,50", "30,15 70,15;50,15 50,85;30,85 70,85", "30,15 78,15;65,15 65,70 55,85 35,85 22,72",
        "25,15 25,85;80,15 25,55 80,85", "25,15 25,85 80,85", "15,85 15,15 50,58 85,15 85,85", "22,85 22,15 78,85 78,15",
        "50,15 28,20 17,42 17,62 28,80 50,85 72,80 83,62 83,42 72,20 50,15", "25,85 25,15 60,15 80,28 80,42 60,53 25,53",
        "50,15 28,20 17,42 17,62 28,80 50,85 72,80 83,62 83,42 72,20 50,15;60,67 87,90", "25,85 25,15 60,15 80,28 80,42 60,53 25,53;53,53 83,85",
        "80,25 65,15 38,15 22,28 25,43 75,57 80,72 65,85 35,85 20,75", "15,15 85,15;50,15 50,85", "22,15 22,65 30,80 50,85 70,80 78,65 78,15",
        "15,15 50,85 85,15", "10,15 28,85 50,40 72,85 90,15", "20,15 80,85;80,15 20,85", "20,15 50,50 80,15;50,50 50,85", "20,15 80,15 20,85 80,85",
        "50,15 30,20 22,40 22,65 30,80 50,85 70,80 78,65 78,40 70,20 50,15", "30,32 50,15 50,85;30,85 70,85",
        "23,30 35,15 62,15 78,30 75,44 22,85 80,85", "25,20 45,15 65,15 80,30 70,45 48,50 70,55 80,72 65,85 40,85 25,78",
        "65,85 65,15 20,62 85,62", "78,15 28,15 25,48 60,48 78,60 78,73 60,85 38,85 23,75",
        "72,18 50,15 30,30 22,58 25,75 40,85 60,85 78,70 75,53 60,45 40,48 23,60", "20,15 80,15 40,85",
        "50,15 30,18 23,32 32,47 68,55 78,70 68,84 32,84 22,70 32,55 68,47 77,32 70,18 50,15",
        "77,45 60,55 37,53 23,40 25,25 40,15 62,15 77,30 78,55 65,78 45,85 30,82"
    };
    final List<float[]> points=new ArrayList<>();final List<Integer> strokeStarts=new ArrayList<>();int reached;boolean drawing;
    TraceCourse(char glyph){int index=GLYPHS.indexOf(glyph);if(index<0)throw new IllegalArgumentException("Unsupported guide");
        for(String stroke:ROUTES[index].split(";")){strokeStarts.add(points.size());String[] pairs=stroke.split(" ");float[] previous=null;
            for(String pair:pairs){String[] xy=pair.split(",");float[] next={Float.parseFloat(xy[0])/100,Float.parseFloat(xy[1])/100};
                if(previous==null)points.add(next);else{float dx=next[0]-previous[0],dy=next[1]-previous[1];int steps=Math.max(1,(int)Math.ceil(Math.hypot(dx,dy)/.025));for(int n=1;n<=steps;n++)points.add(new float[]{previous[0]+dx*n/steps,previous[1]+dy*n/steps});}previous=next;
            }
        }
    }
    boolean finished(){return reached>=points.size();}
    boolean strokeStart(){return strokeStarts.contains(reached);}
    void lift(){drawing=false;}
    boolean touch(float x,float y,boolean down){
        if(finished())return false;if(down)drawing=true;if(!drawing)return false;boolean changed=false;
        while(!finished()){
            if(strokeStart()&&changed){drawing=false;break;}
            float[] p=points.get(reached);if(Math.hypot(x-p[0],y-p[1])>.065)break;reached++;changed=true;
        }return changed;
    }
}
