package de.meiapps.leseabenteuer;

import java.util.*;

/** Slow, untimed letter collecting. Misses and wrong letters retry without losing lives or rewards. */
final class FlightCourse {
    final Random random;final String target;final String[] letters=new String[3];float x=1.15f,y=.5f;int targetLane,collected,mistakes;boolean paused,finished;
    FlightCourse(String target,Random random){this.target=target;this.random=random;next();}
    void next(){x=1.15f;targetLane=random.nextInt(3);for(int lane=0;lane<3;lane++){String option;do{option=String.valueOf(Learning.ALPHABET.charAt(random.nextInt(Learning.ALPHABET.length())));}while(option.equals(target));letters[lane]=lane==targetLane?target:option;}}
    static float laneY(int lane){return .25f+lane*.25f;}
    void steer(float value){y=Math.max(.16f,Math.min(.84f,value));}
    int step(float seconds){if(paused||finished)return 0;float before=x;x-=Math.min(.08f,Math.max(0,seconds))*.30f;
        if(before>.22f&&x<=.22f){int lane=Math.round((y-.25f)/.25f);if(lane>=0&&lane<3&&Math.abs(y-laneY(lane))<.10f){if(lane==targetLane){collected++;if(collected>=6)finished=true;else next();return 1;}mistakes++;next();return -1;}}
        if(x<-.1f){next();return -2;}return 0;
    }
}
