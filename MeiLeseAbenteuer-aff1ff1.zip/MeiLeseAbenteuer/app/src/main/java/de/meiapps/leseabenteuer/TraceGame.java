package de.meiapps.leseabenteuer;

import android.content.Context;
import android.graphics.*;
import android.view.*;

/** A real finger-tracing task, accepting ordered movement along writing centre lines. */
final class TraceGame extends View {
    final TraceCourse course;private final Paint paint=new Paint(3);private final Path guide=new Path(),ink=new Path();private final Runnable completed;private boolean delivered;private int preview=-1;private android.animation.ValueAnimator demo;
    TraceGame(Context context){this(context,'M',()->{});}
    TraceGame(Context context,char glyph,Runnable completed){super(context);course=new TraceCourse(glyph);this.completed=completed;setContentDescription("Schreibspur für "+glyph+". Folge mit dem Finger dem goldenen Punkt.");setFocusable(true);}
    private float side(){return Math.min(getWidth(),getHeight())*.88f;}
    float screenX(float x){return (getWidth()-side())/2+x*side();}
    float screenY(float y){return (getHeight()-side())/2+y*side();}
    void demonstrate(){if(demo!=null)demo.cancel();demo=android.animation.ValueAnimator.ofInt(0,course.points.size()-1);demo.setDuration(3500);demo.addUpdateListener(a->{preview=(Integer)a.getAnimatedValue();invalidate();});demo.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator a){preview=-1;invalidate();}});demo.start();}
    @Override protected void onDetachedFromWindow(){if(demo!=null)demo.cancel();super.onDetachedFromWindow();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float side=side();guide.rewind();ink.rewind();
        for(int i=0;i<course.points.size();i++){float[] p=course.points.get(i);float x=screenX(p[0]),y=screenY(p[1]);if(course.strokeStarts.contains(i))guide.moveTo(x,y);else guide.lineTo(x,y);if(i<course.reached){if(course.strokeStarts.contains(i))ink.moveTo(x,y);else ink.lineTo(x,y);}}
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(side*.10f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setColor(0xffd3dce7);c.drawPath(guide,paint);paint.setStrokeWidth(side*.065f);paint.setColor(0xff55b9b0);c.drawPath(ink,paint);paint.setStyle(Paint.Style.FILL);
        if(!course.finished()){float[] next=course.points.get(preview>=0?preview:course.reached);paint.setColor(0xffffca56);c.drawCircle(screenX(next[0]),screenY(next[1]),side*.055f,paint);paint.setColor(0xffffffff);c.drawCircle(screenX(next[0]),screenY(next[1]),side*.019f,paint);}
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(delivered)return true;int action=e.getActionMasked();if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){course.lift();performClick();return true;}
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE){getParent().requestDisallowInterceptTouchEvent(true);float side=side();course.touch((e.getX()-(getWidth()-side)/2)/side,(e.getY()-(getHeight()-side)/2)/side,action==MotionEvent.ACTION_DOWN);invalidate();if(course.finished()&&!delivered){delivered=true;completed.run();}return true;}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
